The report file contains a list of each attempt at making a model
with the mse, settings and model equation

The export file has the results of the best performing model
of that run.

The training and verification sets are in the same group
so the verification set is the last 200 values in the CSV

data-random.csv is the data in a randomised order that was put into the algorithm.
Some rows are ommitted in the export file if they failed validation on import

The excel document just has an extra graph of the error over the set